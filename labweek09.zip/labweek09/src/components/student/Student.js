import React from 'react'
function Student(props){
    return(
        <React.Fragment>
        <h1>Welcome to Fullstack Development - I</h1>
        <h2>React JS Programming Week09 Lab Exercise</h2>
        <h3>101322849</h3>
        <h4>Lien Le</h4>
        <h5>George Brown College, Toronto</h5>
        </React.Fragment>
    );
}
export default Student